#include <iostream>
#include <string>
using namespace std;

// Enumerated type for genres
enum Genre { Fiction, NonFiction, Science, History };

// Nested structure for publisher details
struct Publisher {
    string name;
    string city;
};

// Structure for book details
struct Book {
    string title;
    string author;
    string ISBN;
    int year;
    string status;
    Genre genre;
    Publisher publisher;
};

// Function prototypes
void addBook(Book library[], int& count);
Book* searchBookByISBN(Book library[], int count, string isbn);
void updateStatus(Book* bookPtr);
void displayBook(const Book& book);

// Main function
int main() {
    const int MAX_BOOKS = 100;
    Book library[MAX_BOOKS];
    int count = 0;
    int choice;
    string isbn;

    do {
        cout << "\n====== Library Catalog System ======\n";
        cout << "1. Add a new book\n";
        cout << "2. Search for a book by ISBN\n";
        cout << "3. Update book status\n";
        cout << "4. Display all books\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1:
            addBook(library, count);
            break;

        case 2:
            cout << "Enter ISBN to search: ";
            getline(cin, isbn);
            {
                Book* found = searchBookByISBN(library, count, isbn);
                if (found != nullptr)
                    displayBook(*found);
                else
                    cout << "Book not found.\n";
            }
            break;

        case 3:
            cout << "Enter ISBN to update status: ";
            getline(cin, isbn);
            {
                Book* found = searchBookByISBN(library, count, isbn);
                if (found != nullptr)
                    updateStatus(found);
                else
                    cout << "Book not found.\n";
            }
            break;

        case 4:
            for (int i = 0; i < count; i++) {
                cout << "\nBook #" << i + 1 << ":\n";
                displayBook(library[i]);
            }
            break;

        case 5:
            cout << "Exiting program. Goodbye!\n";
            break;

        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}

// Function to add a new book
void addBook(Book library[], int& count) {
    if (count >= 100) {
        cout << "Library is full!\n";
        return;
    }

    Book& b = library[count];
    cout << "Enter title: ";
    getline(cin, b.title);
    cout << "Enter author: ";
    getline(cin, b.author);
    cout << "Enter ISBN: ";
    getline(cin, b.ISBN);
    cout << "Enter publication year: ";
    cin >> b.year;
    cin.ignore();
    cout << "Enter publisher name: ";
    getline(cin, b.publisher.name);
    cout << "Enter publisher city: ";
    getline(cin, b.publisher.city);
    cout << "Select genre (0=Fiction, 1=NonFiction, 2=Science, 3=History): ";
    int g;
    cin >> g;
    cin.ignore();
    b.genre = static_cast<Genre>(g);
    b.status = "Available";

    count++;
    cout << "Book added successfully!\n";
}

// Function to search for a book by ISBN
Book* searchBookByISBN(Book library[], int count, string isbn) {
    for (int i = 0; i < count; i++) {
        if (library[i].ISBN == isbn)
            return &library[i];
    }
    return nullptr; // Not found
}

// Function to update book status using pointer
void updateStatus(Book* bookPtr) {
    cout << "Current status: " << bookPtr->status << endl;
    cout << "Enter new status (Available/Checked Out): ";
    getline(cin, bookPtr->status);
    cout << "Status updated successfully!\n";
}

// Function to display book information
void displayBook(const Book& book) {
    cout << "Title: " << book.title << endl;
    cout << "Author: " << book.author << endl;
    cout << "ISBN: " << book.ISBN << endl;
    cout << "Year: " << book.year << endl;
    cout << "Status: " << book.status << endl;
    cout << "Genre: ";
    switch (book.genre) {
    case Fiction: cout << "Fiction"; break;
    case NonFiction: cout << "Non-Fiction"; break;
    case Science: cout << "Science"; break;
    case History: cout << "History"; break;
    }
    cout << endl;
    cout << "Publisher: " << book.publisher.name << " (" << book.publisher.city << ")\n";
}
